from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import Client, Project
from .Serializer import ClientSerializer, ProjectSerializer
from django.contrib.auth.models import User

class ClientViewSet(viewsets.ModelViewSet):
    queryset = Client.objects.all()
    serializer_class = ClientSerializer
    
   

    def perform_create(self, serializer):
        serializer.save(created_by=User.objects.first())  # Default user for unauthenticated requests

class ProjectViewSet(viewsets.ModelViewSet):
    queryset = Project.objects.all()
    serializer_class = ProjectSerializer

    def perform_create(self, serializer):
        client_id = self.request.data.get('client_id')
        client = Client.objects.get(id=client_id)
        serializer.save(client=client, created_by=User.objects.first())  # Default user for unauthenticated requests

    @action(detail=False, methods=['get'])
    def assigned_to_me(self, request):
        user = User.objects.first()  # Default user for unauthenticated requests
        projects = Project.objects.filter(created_by=user)
        serializer = self.get_serializer(projects, many=True)
        return Response(serializer.data)

 